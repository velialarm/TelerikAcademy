package com.example.telerik_demo_live;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UserInfo extends Activity implements View.OnClickListener
{
	
	EditText passOne, passTwo;
	View v;
	Button btnChange;
	SQLiteDatabaseContentProvider mDd;
	UserDataPreference userData;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.user_info);
		passOne = (EditText) findViewById(R.id.editPass);
		passTwo = (EditText) findViewById(R.id.editPass2);
		btnChange = (Button) findViewById(R.id.button1);
		btnChange.setOnClickListener(this);
		mDd = new SQLiteDatabaseContentProvider(getApplicationContext());
		userData = new UserDataPreference(getApplicationContext());
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (R.id.button1 == v.getId()) {
			// its time to change password
			if (passOne.getText().toString()
			        .equals(passTwo.getText().toString())) {
				// change the currentPassword
				mDd.updateUserData(passOne.getText().toString());
				userData.rememeber(false);
			} else {
				// password missmatch
				Toast.makeText(this, "Passwords dont match !",
				        Toast.LENGTH_SHORT).show();
			}
		}
	}
	
}
