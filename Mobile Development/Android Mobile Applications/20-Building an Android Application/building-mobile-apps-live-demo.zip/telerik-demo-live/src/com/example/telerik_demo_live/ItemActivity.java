package com.example.telerik_demo_live;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

@SuppressLint("NewApi")
public class ItemActivity extends Activity implements OnItemClickListener,View.OnClickListener
{
	
	ListView list;
	private Context mContext = this;
	CustomListViewAdapter adapter;
	private Button btnBasket;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.item_layout);
		Bundle bundle = getIntent().getExtras();
		String userName = bundle.getString(mContext.getString(R.string.user_pass_data));
		if(userName != null) {
			ActionBar bar = getActionBar();
			bar.setTitle("You just logged in as : " + userName);
			bar.setHomeButtonEnabled(true);
			bar.setDisplayHomeAsUpEnabled(true);
		}
				
		btnBasket = (Button)findViewById(R.id.button1);
		btnBasket.setOnClickListener(this);
		
		//listview init code
		adapter = new CustomListViewAdapter(mContext,
		        R.layout.list_row);
		ItemBase item = new ItemBase();
		item.setId(0);
		item.setItem_desc("Some text over here !");
		item.setItem_create_date("13.10.2014");
		item.setItem_owner("Test");
		item.setItem_name("Yeah I am free !");
		adapter.add(item);
		list = (ListView) findViewById(R.id.listView1);
		list.setAdapter(adapter);
		
		list.setOnItemClickListener(this);
		
	}
	

	@Override
    public boolean onMenuItemSelected(int featureId, MenuItem item) {
	    // TODO Auto-generated method stub
		Toast.makeText(this, item.getTitle(), Toast.LENGTH_SHORT).show();
		//open change user profile screen
		Intent intent = new Intent(ItemActivity.this,UserInfo.class);
		startActivity(intent);
	    return super.onMenuItemSelected(featureId, item);
    }


	@Override
    public void onItemClick(AdapterView<?> parent, View view, int position,
            long id) {
	    // TODO Auto-generated method stub
	    Intent intent = new Intent(ItemActivity.this,ItemInfoActivity.class);
	    ItemBase temp = adapter.getItem(position);
	    intent.putExtra(mContext.getString(R.string.user_pass_data), "Test");
	    intent.putExtra("ITEMNAME", temp.getItem_name());
	    intent.putExtra("ITEMDESC", temp.getItem_desc());
	    startActivity(intent);
    }

	@Override
    public void onClick(View v) {
	    // TODO Auto-generated method stub
	    if(R.id.button1 == v.getId()) {
	    	Intent intent = new Intent(ItemActivity.this,BasketActivity.class);
			intent.putExtra("USERNAME", "Test");
			startActivity(intent);
	    }
    }
}
