package com.example.telerik_demo_live;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

@SuppressLint("NewApi")
public class BasketActivity extends Activity implements OnItemClickListener
{

	ListView list;
	CustomListViewAdapter adapter;
	private Context mContext = this;
	private SQLiteDatabaseContentProvider mDatabaseInstance;
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
	    // TODO Auto-generated method stub
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.basket_layout);
	    
		Bundle bundle = getIntent().getExtras();
		String userName = bundle.getString(mContext.getString(R.string.user_pass_data));
		if(userName != null) {
			ActionBar bar = getActionBar();
			bar.setTitle("You just logged in as : " + userName);
		}
	    
	    adapter = new CustomListViewAdapter(mContext,
		        R.layout.list_row);
	    mDatabaseInstance = new SQLiteDatabaseContentProvider(mContext);
	    for(ItemBase item : mDatabaseInstance.getAllBasketItems("Test")) {
	    	adapter.add(item);
	    }
	    list = (ListView) findViewById(R.id.listView1);
		list.setAdapter(adapter);
		
		list.setOnItemClickListener(this);
		
    }

	@Override
    public void onItemClick(AdapterView<?> parent, View view, int position,
            long id) {
		
		adapter.remove(adapter.getItem(position));
		adapter.notifyDataSetChanged();
		mDatabaseInstance.emptyBasket(position);
	    // TODO Auto-generated method stub
	    
    }
	
}
