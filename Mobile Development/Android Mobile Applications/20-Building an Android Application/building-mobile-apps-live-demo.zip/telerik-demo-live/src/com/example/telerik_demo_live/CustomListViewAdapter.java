package com.example.telerik_demo_live;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CustomListViewAdapter extends ArrayAdapter<ItemBase>
{
	
	static class ViewHolder
	{
		TextView title, desc, date;
		ImageView item_image;
	}
	
	private int customResource;
	private Context context;
	
	public CustomListViewAdapter(Context context, int resource)
	{
		super(context, resource);
		customResource = resource;
		this.context = context;
		// TODO Auto-generated constructor stub
	}
	
	private void initComponents(View v, ViewHolder holder) {
		holder.title = (TextView) v.findViewById(R.id.title);
		holder.desc = (TextView) v.findViewById(R.id.desc);
		holder.date = (TextView) v.findViewById(R.id.date);
		holder.item_image = (ImageView) v.findViewById(R.id.list_image);
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see android.widget.ArrayAdapter#getView(int, android.view.View,
	 * android.view.ViewGroup)
	 */
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder holder = null;
		
		if (convertView == null) {
			holder = new ViewHolder();
			LayoutInflater inflate = (LayoutInflater) context
			        .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflate.inflate(customResource, parent, false);
			if (convertView != null)
				initComponents(convertView, holder);
			
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		
		holder.title.setText(this.getItem(position).getItem_name());
		holder.desc.setText(this.getItem(position).getItem_desc());
		holder.date.setText(this.getItem(position).getItem_create_date());
		holder.item_image.setImageBitmap(BitmapFactory.decodeResource(
		        context.getResources(), R.drawable.ic_launcher));
		
		return convertView;
	}
	
}
