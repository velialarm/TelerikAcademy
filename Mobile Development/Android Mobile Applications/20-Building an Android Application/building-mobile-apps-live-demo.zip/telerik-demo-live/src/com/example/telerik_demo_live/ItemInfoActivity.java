package com.example.telerik_demo_live;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

@SuppressLint("NewApi")
public class ItemInfoActivity extends Activity implements View.OnClickListener
{
	
	private ImageView item_image;
	private TextView item_title, item_desc;
	private Button btnAddToCart;
	private SQLiteDatabaseContentProvider mDatabaseInstance;
	private Context mContext = this;
	
	private void initElements() {
		item_image = (ImageView) findViewById(R.id.imageView1);
		item_title = (TextView) findViewById(R.id.item_name);
		item_desc = (TextView) findViewById(R.id.item_desc);
		btnAddToCart = (Button) findViewById(R.id.button1);
		btnAddToCart.setOnClickListener(this);
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.item_info);
		initElements();
		
		Bundle bundle = getIntent().getExtras();
		String userName = bundle.getString(mContext.getString(R.string.user_pass_data));
		if(userName != null) {
			ActionBar bar = getActionBar();
			bar.setTitle("You just logged in as : " + userName);
		}
	    
		
		item_image.setImageBitmap(BitmapFactory.decodeResource(getResources(),
		        R.drawable.ic_launcher));
		item_title.setText(bundle.getString("ITEMNAME"));
		// item_desc.setText(bundle.getString("ITEMDESC"));
		
		mDatabaseInstance = new SQLiteDatabaseContentProvider(
		        getApplicationContext());
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		// its time for shop
		if (R.id.button1 == v.getId()) {
			mDatabaseInstance.addItemToCart("Test", 0);
		}
	}
	
}
