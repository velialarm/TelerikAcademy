package com.example.telerik_demo_live;

public class ItemBase
{
	private int id;
	private String item_name;
	private String item_desc;
	
	/**
	 * @return the item_desc
	 */
	public final String getItem_desc() {
		return item_desc;
	}
	
	/**
	 * @param item_desc
	 *            the item_desc to set
	 */
	public final void setItem_desc(String item_desc) {
		this.item_desc = item_desc;
	}
	
	/**
	 * @return the item_owner
	 */
	public final String getItem_owner() {
		return item_owner;
	}
	
	/**
	 * @param item_owner
	 *            the item_owner to set
	 */
	public final void setItem_owner(String item_owner) {
		this.item_owner = item_owner;
	}
	
	/**
	 * @return the item_create_date
	 */
	public final String getItem_create_date() {
		return item_create_date;
	}
	
	/**
	 * @param item_create_date
	 *            the item_create_date to set
	 */
	public final void setItem_create_date(String item_create_date) {
		this.item_create_date = item_create_date;
	}
	
	private String item_owner;
	private String item_create_date;
	
	public String getItem_name() {
		return item_name;
	}
	
	public final void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	
	public final int getId() {
		return id;
	}
	
	public final void setId(int id) {
		this.id = id;
	}
}
