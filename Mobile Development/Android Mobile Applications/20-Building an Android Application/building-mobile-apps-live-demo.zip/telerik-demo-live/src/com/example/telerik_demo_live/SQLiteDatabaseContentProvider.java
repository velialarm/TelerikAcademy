package com.example.telerik_demo_live;

import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class SQLiteDatabaseContentProvider
{
	private SQLiteManager mManager;
	private Context context;
	private SQLiteDatabase mDb;
	
	public SQLiteDatabaseContentProvider(Context context)
	{
		this.context = context;
		this.mManager = new SQLiteManager(context);
		mDb = mManager.getReadableDatabase();
	}
	
	public boolean loginUser(String username, String password) {
		Cursor userCursor = null;
		
		if (username != null && password != null) {
			String sql = "SELECT * FROM User WHERE username='" + username
			        + "' " + "AND password ='" + password + "'";
			
			userCursor = mDb.rawQuery(sql, null);
			boolean isLoggedIn = userCursor.moveToFirst();
			if (isLoggedIn) {
				// my user exist in the database record
				userCursor.close();
				return true;
			}
			
		}
		if (userCursor != null)
			userCursor.close();
		return false;
	}
	
	public boolean addItemToCart(String userName, int itemID) {
		if (userName != null) {
			String sql = "INSERT INTO Basket(user_name,item_id) VALUES('"
			        + userName + "','" + String.valueOf(itemID) + "'" + ")";
			mDb.execSQL(sql);
			return true;
		}
		return false;
	}
	
	public void updateUserData(String password) {
		String sql = "UPDATE User SET password='" + password + "' "
		        + "WHERE username='Telerik';";
		mDb.execSQL(sql);		
	}
	
	public void emptyBasket(int itemID) {
		String sql = "DELETE FROM Basket WHERE item_id = '" + itemID + "'";
		mDb.execSQL(sql);	
	}
	
	public ArrayList<ItemBase> getAllBasketItems(String username) {
		ArrayList<ItemBase> temp = new ArrayList<ItemBase>();
		ArrayList<Integer> items = new ArrayList<Integer>();
		String sql = "SELECT * FROM Basket WHERE user_name='" + username + "'";
		Cursor allItems = mDb.rawQuery(sql, null);
		
		while (allItems.moveToNext()) {
			items.add(allItems.getInt(1));
		}
		allItems.close();
		
		for (Integer in : items) {
			String tempSql = "SELECT * FROM Items WHERE id='"
			        + String.valueOf(1) + "'";
			Cursor item_cursor = mDb.rawQuery(tempSql, null);
			item_cursor.moveToFirst();
			ItemBase baseItem = new ItemBase();
			baseItem.setId(item_cursor.getInt(0));
			baseItem.setItem_name(item_cursor.getString(1));
			baseItem.setItem_desc(item_cursor.getString(2));
			baseItem.setItem_create_date(item_cursor.getString(4));
			temp.add(baseItem);
		}
		
		return temp;
		
	}
}
