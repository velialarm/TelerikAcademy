/** Automatically generated file. DO NOT MODIFY */
package com.example.telerik_demo_live;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}