/** Automatically generated file. DO NOT MODIFY */
package com.example.threadingnothreading;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}