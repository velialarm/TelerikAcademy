package com.telerikacademy.boxbreaker.game.engine;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;

import com.telerikacademy.boxbreaker.R;
import com.telerikacademy.boxbreaker.game.engine.elements.Ball;
import com.telerikacademy.boxbreaker.game.engine.elements.Box;
import com.telerikacademy.boxbreaker.game.engine.elements.Explosion;
import com.telerikacademy.boxbreaker.game.engine.elements.GameObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GameManager {

    private Rect bounds;

    private final Context context;
    private List<Box> boxes;
    private List<Explosion> explosions;
    private int unitSize;
    private int[] colors;
    private Random random;

    private Ball ball;
    private float velocityX;
    private float velocityY;

    private int ballVelocityX;
    private int ballVelocityY;
    private int ballX;
    private int ballY;

    public GameManager(Context context) {
        this.context = context;
        init();
    }

    private void init() {
        this.boxes = new ArrayList<Box>();
        this.bounds = new Rect();
        this.ball = new Ball(this.context.getResources().getDimension(R.dimen.stroke_width));
        this.colors = new int[]{
                Color.YELLOW,
                Color.GREEN,
                Color.MAGENTA,
                Color.RED,
                Color.CYAN,
                Color.BLUE
        };

        this.random = new Random();
        this.explosions = new ArrayList<Explosion>();
    }

    public void update() {
        if (inFling()) {

            updateBallVelocity();

            this.ball.translate(ballVelocityX, ballVelocityY);

            for (Box box : this.boxes) {
                if (!box.isHit() && box.color() == this.ball.getColor() && intersects(this.ball, box)) {
                    box.setHit(true);
                    Explosion explosion = new Explosion(box.color());
                    explosion.arrange(box.x(), box.y(), box.size());
                    this.explosions.add(explosion);
                }
            }

            bounce();

            updateVelocity();

            if (!inFling()) {
                resetBall();
            }
        }
    }

    private void resetBall() {
        this.ball.setColor(getRandomColor());
        this.ball.translate(this.ballX - this.ball.x(), this.ballY - this.ball.y());
    }

    private int getRandomColor() {
        return this.colors[this.random.nextInt(this.colors.length)];
    }

    private int circleDistanceX;
    private int circleDistanceY;
    private int cornerDistance;

    boolean intersects(Ball circle, GameObject rect) {
        circleDistanceX = Math.abs((ball.x() + ball.radius()) - (rect.x() + (rect.size() / 2)));
        circleDistanceY = Math.abs((ball.y() + ball.radius()) - (rect.y() + (rect.size() / 2)));

        if (circleDistanceX > (rect.size() / 2 + circle.radius())) {
            return false;
        }
        if (circleDistanceY > (rect.size() / 2 + circle.radius())) {
            return false;
        }

        if (circleDistanceX <= (rect.size() / 2)) {
            return true;
        }
        if (circleDistanceY <= (rect.size() / 2)) {
            return true;
        }

        cornerDistance = ((circleDistanceX - (rect.size() / 2)) * (circleDistanceX - (rect.size() / 2))) +
                ((circleDistanceY - (rect.size() / 2)) *(circleDistanceY - (rect.size() / 2)));

        return (cornerDistance <= (circle.radius() * circle.radius()));
    }

    private void updateVelocity() {
        if (ballVelocityX == 0) {
            this.velocityX = 0;
        } else if (velocityX > 0) {
            velocityX -= Math.abs(ballVelocityX);
            if (velocityX < 0)
                velocityX = 0;
        } else if (velocityX < 0) {
            velocityX += Math.abs(ballVelocityX);
            if (velocityX > 0)
                velocityX = 0;
        }

        if (ballVelocityY == 0) {
            this.velocityY = 0;
        } else if (velocityY > 0) {
            velocityY -= Math.abs(ballVelocityY);
            if (velocityY < 0)
                velocityY = 0;
        } else if (velocityY < 0) {
            velocityY += Math.abs(ballVelocityY);
            if (velocityY > 0)
                velocityY = 0;
        }
    }

    private void bounce() {
        if (this.ball.x() + this.ball.size() >= this.bounds.right) {
            this.velocityX = -velocityX;
        } else if (this.ball.x() <= this.bounds.left) {
            this.velocityX = Math.abs(velocityX);
        }

        if (this.ball.y() <= this.bounds.top) {
            this.velocityY = Math.abs(velocityY);
        } else if (ball.y() + ball.size() >= this.bounds.bottom) {
            this.velocityY = -velocityY;
        }
    }

    private void updateBallVelocity() {
        this.ballVelocityX = (int) (this.velocityX * this.ball.speed());
        this.ballVelocityY = (int) (this.velocityY * this.ball.speed());
    }

    private boolean inFling() {
        return this.velocityX != 0 || this.velocityY != 0;
    }

    public void arrange(int left, int top, int right, int bottom) {
        this.bounds.left = left;
        this.bounds.top = top;
        this.bounds.right = right;
        this.bounds.bottom = bottom;

        this.unitSize = (int) (this.bounds.height() * 0.1);
        ballX = this.bounds.left + this.bounds.width() - (unitSize * 2);
        ballY = this.bounds.top + (this.bounds.height() / 2) - (unitSize / 2);

        this.ball.arrange(ballX, ballY, unitSize);

        float strokeWidth = this.context.getResources().getDimension(R.dimen.stroke_width);

        this.boxes.clear();
        for (int row = 0, rowsSize = 10; row < rowsSize; row++) {
            for (int col = 0, colsSize = 10; col < colsSize; col++) {
                Box box = new Box(strokeWidth, getRandomColor());
                box.arrange(col * unitSize, row * unitSize, unitSize);
                this.boxes.add(box);
            }
        }
    }

    public void render(Canvas canvas) {
        for (GameObject box : this.boxes)
            box.render(canvas);

        this.ball.render(canvas);

        for(GameObject explosion : this.explosions) {
            explosion.render(canvas);
        }
    }

    public boolean onScroll(float distanceX, float distanceY) {
        if (inFling())
            return false;

        this.ball.translate(-(int) distanceX, -(int) distanceY);

        return true;
    }

    public boolean onFling(float velocityX, float velocityY) {
        if (inFling())
            return false;

        this.velocityX = velocityX;
        this.velocityY = velocityY;

        return true;
    }

    public void onLongPress() {
        velocityX = 0;
        velocityY = 0;

        resetBall();
    }
}
