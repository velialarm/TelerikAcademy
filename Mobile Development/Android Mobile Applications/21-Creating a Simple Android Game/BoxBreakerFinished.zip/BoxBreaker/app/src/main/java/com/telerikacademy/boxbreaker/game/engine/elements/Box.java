package com.telerikacademy.boxbreaker.game.engine.elements;

import android.graphics.Canvas;
import android.graphics.Paint;

/**
 * Created by jekov on 10/13/14.
 */
public class Box extends GameObject {

    private boolean hit;
    private int color;
    private Paint paint;

    public Box(float strokeWidth, int color) {
        paint = new Paint();
        this.paint.setStrokeWidth(strokeWidth);
        this.paint.setColor(color);
        this.color = color;
    }

    public int color() {
        return this.color;
    }

    @Override
    public void render(Canvas canvas) {
        if (!hit)
            canvas.drawRect(x, y, x + size, y + size, paint);
    }

    public boolean isHit() {
        return hit;
    }

    public void setHit(boolean hit) {
        this.hit = hit;
    }
}
