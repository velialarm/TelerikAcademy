package com.telerikacademy.boxbreaker.game.engine.elements;

import android.graphics.Canvas;
import android.graphics.Rect;

public class GameObject {

    protected int x;
    protected int y;
    protected int size;

    public void render(Canvas canvas){}

    public void arrange(int left, int top, int size){
        this.x = left;
        this.y = top;

        this.size = size;
    }

    public int x() {
        return this.x;
    }

    public int y() {
        return this.y;
    }

    public int size() {
        return this.size;
    }
}
