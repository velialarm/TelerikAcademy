package com.telerikacademy.boxbreaker.game.engine.elements;

import android.graphics.Canvas;
import android.graphics.Paint;

/**
 * Created by jekov on 10/13/14.
 */
public class Explosion extends GameObject {

    private int explosionStep;
    private static final int ALPHA_STEP = 51;
    private Paint paint;

    public Explosion(int color) {
        this.paint = new Paint();
        this.paint.setColor(color);
    }

    @Override
    public void arrange(int left, int top, int size) {
        super.arrange(left, top, size);

        this.explosionStep = (int) (this.size * .1);
    }

    @Override
    public void render(Canvas canvas) {
        if (paint.getAlpha() > 0) {

            canvas.drawRect(x, y, x + size, y + size, paint);

            this.paint.setAlpha(this.paint.getAlpha() - ALPHA_STEP);
            this.x -= explosionStep;
            this.y -= explosionStep;
            this.size += explosionStep * 2;
        }
    }
}
