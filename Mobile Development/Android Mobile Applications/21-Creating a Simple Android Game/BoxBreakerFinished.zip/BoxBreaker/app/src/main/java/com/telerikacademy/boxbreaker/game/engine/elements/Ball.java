package com.telerikacademy.boxbreaker.game.engine.elements;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

/**
 * Created by jekov on 10/13/14.
 */
public class Ball extends GameObject {

    private float speed = .01f;

    private Paint paint;
    private int radius;

    private int color = Color.YELLOW;

    public Ball(float strokeWidth) {
        this.paint = new Paint();
        this.paint.setStrokeWidth(strokeWidth);
    }

    @Override
    public void arrange(int left, int top, int size) {
        super.arrange(left, top, size);

        this.radius = size / 2;
    }

    @Override
    public void render(Canvas canvas) {
        this.paint.setStyle(Paint.Style.FILL);
        this.paint.setColor(this.color);
        canvas.drawCircle(this.x + radius, this.y + radius, radius, paint);
        this.paint.setColor(Color.WHITE);
        this.paint.setStyle(Paint.Style.STROKE);
        canvas.drawCircle(this.x + radius, this.y + radius, radius, paint);
    }

    public float speed() {
        return this.speed;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public void translate(int distanceX, int distanceY) {
        this.x += distanceX;
        this.y += distanceY;
    }

    public int radius() {
        return this.radius;
    }
}
