package com.telerikacademy.boxbreaker.game.engine;

import android.graphics.Canvas;


import com.telerikacademy.boxbreaker.game.engine.elements.GameObject;

import java.util.ArrayList;
import java.util.List;

public class GameManager extends GameObject {

    private List<GameObject> gameObjects;

    public GameManager() {
        init();
    }

    private void init() {
        this.gameObjects = new ArrayList<GameObject>();
    }

    public void update() {

    }

    @Override
    public void arrange(int left, int top, int right, int bottom) {
        super.arrange(left, top, right, bottom);

        this.invalidateArrange();
    }

    private void invalidateArrange() {
    }

    @Override
    public void render(Canvas canvas) {
    }
}
