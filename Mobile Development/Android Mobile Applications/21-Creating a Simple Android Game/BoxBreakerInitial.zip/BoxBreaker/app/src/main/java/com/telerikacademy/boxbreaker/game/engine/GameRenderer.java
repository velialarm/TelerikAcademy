package com.telerikacademy.boxbreaker.game.engine;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.Calendar;

public class GameRenderer extends SurfaceView implements SurfaceHolder.Callback {

    private static final int CLEAR_COLOR = Color.parseColor("#222222");

    private final GameThread gameThread;
    private final GameManager gameManager;

    public GameRenderer(Context context) {
        super(context);

        getHolder().addCallback(this);
        setFocusable(true);

        this.gameThread = new GameThread(getHolder(), this);
        this.gameManager = new GameManager();
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        this.gameThread.setRunning(true);
        this.gameThread.start();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        while (true) {
            try {
                this.gameThread.join();
                break;
            } catch (InterruptedException e) {
                Log.d("Box Breaker", "Trying to shutdown game thread...");
            }
        }
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);

        if (changed)
            this.gameManager.arrange(left, top, right, bottom);
    }

    public void update() {
        this.gameManager.update();
    }

    public void render(Canvas canvas) {
        canvas.drawColor(CLEAR_COLOR);
        this.gameManager.render(canvas);
    }
}
