package com.telerikacademy.boxbreaker.game.engine.elements;

import android.graphics.Canvas;
import android.graphics.Rect;

public class GameObject {
    public void render(Canvas canvas){}

    public void arrange(int left, int top, int right, int bottom){}
}
