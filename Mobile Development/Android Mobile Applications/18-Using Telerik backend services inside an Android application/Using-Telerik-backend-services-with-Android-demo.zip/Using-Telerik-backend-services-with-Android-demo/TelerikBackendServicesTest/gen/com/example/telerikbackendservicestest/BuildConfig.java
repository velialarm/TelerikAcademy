/** Automatically generated file. DO NOT MODIFY */
package com.example.telerikbackendservicestest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}