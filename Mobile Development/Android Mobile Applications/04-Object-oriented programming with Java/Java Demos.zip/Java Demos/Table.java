package test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Table {

	private String fileName;
	private final String HOME_DIR = "C:/Users/Dimitar/Desktop/";
	private ArrayList<Element> elements;

	public Table(String fn) {
		this.fileName = HOME_DIR + fn;
		this.elements = new ArrayList<Element>();
	}

	public void readFile() throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(fileName));
		try {
			String line = br.readLine();

			while (line != null) {
				line = br.readLine();
				if (line != null) {
					String[] elementData = line.split(",");
					elements.add(new Element(elementData[0], Integer
							.valueOf(elementData[1]), elementData[2], Double
							.valueOf(elementData[3])));
				}
			}
		} finally {
			br.close();
		}
	}
	
	public void diplayElements() {
		for(Element elm : this.elements){
			System.out.println(elm.toString());
		}
	}

}
