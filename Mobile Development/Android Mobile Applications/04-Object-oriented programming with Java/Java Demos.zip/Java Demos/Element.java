package test;

public class Element {

	private String element;
	private int atomicNum;

	public String getElement() {
		return element;
	}

	public void setElement(String element) {
		this.element = element;
	}

	public int getAtomicNum() {
		return atomicNum;
	}

	public void setAtomicNum(int atomicNum) {
		this.atomicNum = atomicNum;
	}

	public String getSym() {
		return sym;
	}

	public void setSym(String sym) {
		this.sym = sym;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	private String sym;
	private double weight;

	public Element(String element, int atomicNum, String sym, double weight) {
		this.element = element;
		this.atomicNum = atomicNum;
		this.sym = sym;
		this.weight = weight;
	}

	@Override
	public String toString() {
		return this.element + " : " + this.atomicNum + " : " + this.sym + " : "
				+ this.weight;
	}

}
