package test;

import java.util.Comparator;

public class Temprature implements Comparator<Temprature> {

	private char type;
	private int value;

	Temprature() {
		// TODO
		type = 'C';
		this.value = 0;
	}

	Temprature(char type) {
		this.type = type;
		this.value = 0;
	}

	Temprature(char type, int value) {
		this.type = type;
		this.value = value;
	}

	public String getTemp() {
		return this.value + String.valueOf(type);
	}

	public int getCelsium() {
		if (type == 'C') {
			return this.value;
		} else {
			return 5 * (value - 32) / 9;
		}
	}

	public int getFarenheit() {
		if (type == 'F') {
			return this.value;
		} else {
			return 9 * (value / 5) + 32;
		}
	}

	public boolean changeState(char state) {
		if (state == 'C' || state == 'F') {
			if (type == 'C') {
				type = 'F';
				value = 9 * (value / 5) + 32;
			} else {
				type = 'C';
				value = 5 * (value - 32) / 9;
			}
			return true;
		} else {
			return false;
		}
	}

	@Override
	public int compare(Temprature o1, Temprature o2) {
		if (o1.value == o2.value) {
			// are the same
			return 0;
		} else if (o1.value > o2.value) {
			return 1;
		} else if (o1.value < o2.value) {
			return -1;
		}		
		return -5;
	}
	

}
