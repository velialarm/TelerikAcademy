<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php
echo $title; 
?></title>

<link href="css/style.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id="content">
<h1>
<?php
echo $title; 
?>
</h1>