<?php
include '../views/header.php';
?>
<div><a href="?">Начало</a></div>
<div style="width: 200px;margin: 0 auto">
    <span style="text-align: center"><h1>404</h1></span>
    <img src="img/404.gif"/>
    <span style="text-align: center"><h1>404</h1></span>
</div>
<p style="font-size: 0.5em">Опа, група преяли с вафли мероморчета откраднаха страницата и я заложиха за 4 дирана, за да си купят салманал за мазане</p>

<?php
include '../views/footer.php';


