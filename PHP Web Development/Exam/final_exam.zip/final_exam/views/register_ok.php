<?php
include '../views/header.php';
?>
<div><a href="?">Начало</a> <a href="?p=login">Вход</a> </div>
<h1>Успешна регистрация! Може да влезете в системата!</h1>

<?php
include '../views/footer.php';


