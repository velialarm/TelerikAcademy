<?php

include '../views/header.php';
if ($_SESSION['is_logged']) {
    echo '<div>Здравей ' . $_SESSION['user_data']['email'] . ' <a href="?p=new_auction">Нова обява</a> <a href="?p=logout">Изход</a></div>';
} else {
    echo '<div><a href="?p=login">Вход</a> <a href="?p=register">Регистрация</a> </div>';
}
?>
<p>!!!Тук трябва да е списъка с активните търгове!!!</p>
<?php

include '../views/footer.php';


