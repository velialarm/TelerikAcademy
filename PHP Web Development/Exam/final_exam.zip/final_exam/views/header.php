<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title><?=$page_title;?></title>
</head>
<body>
    