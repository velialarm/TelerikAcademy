<?php
$cnf['db_host'] = 'localhost';
$cnf['db_user'] = 'telerik';
$cnf['db_pass'] = 'qwerty';
$cnf['db_database'] = 'auction';
$cnf['db_port'] = 3306;
