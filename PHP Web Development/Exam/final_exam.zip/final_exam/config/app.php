<?php
$cnf['controller_key']='p';
$cnf['controller_method_key']='m';



