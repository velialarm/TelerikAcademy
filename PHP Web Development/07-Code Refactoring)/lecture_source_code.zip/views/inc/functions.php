<?php
function render($data,$name){           
    include $name;       
}