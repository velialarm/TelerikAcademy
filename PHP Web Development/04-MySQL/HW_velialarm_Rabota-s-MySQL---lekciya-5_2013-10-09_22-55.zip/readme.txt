Setting to connect to database

host: localhost
db_username: homeworks
db_password: qwerty
database_name: homework

insert database to MySQL Server from file "database.sql"