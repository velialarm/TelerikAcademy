﻿namespace JustBelot.Common
{
    public enum CardSuit
    {
        Spades = 3, // ♠
        Hearts = 2, // ♥
        Diamonds = 1, // ♦
        Clubs = 0, // ♣
    }
}
