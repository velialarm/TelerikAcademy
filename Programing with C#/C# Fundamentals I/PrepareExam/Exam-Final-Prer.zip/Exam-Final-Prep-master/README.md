Exam-Final-Prep
===============

The source code for the final exam prep for C# part 1 at Telerik Academy 01/12/2013
