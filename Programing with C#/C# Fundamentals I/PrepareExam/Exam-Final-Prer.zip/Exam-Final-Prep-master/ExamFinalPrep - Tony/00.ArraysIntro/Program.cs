﻿namespace _00.ArraysIntro
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int[,] matrix = new int[8, 8];

            matrix[0, 0] = 5;
        }
    }
}