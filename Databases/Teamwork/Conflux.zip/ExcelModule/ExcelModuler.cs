﻿namespace ExcelModule
{
    public class ExcelModuler
    {
        public static void Main()
        {
        }
    }
}
