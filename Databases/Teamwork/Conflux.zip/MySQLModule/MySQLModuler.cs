﻿namespace MySQLModule
{
    public class MySQLModuler
    {
        public void SaveJson(string reportAsJsonArray)
        {
            throw new System.NotImplementedException();
        }
    }
}
