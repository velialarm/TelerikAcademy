﻿You can see my work on https://confluxteam.codeplex.com
or found me with username: velialarm