﻿namespace XMLModule
{
    public class XMLModuler
    {
        public static void Main()
        {
        }
    }
}
