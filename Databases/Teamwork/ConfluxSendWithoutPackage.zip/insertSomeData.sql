﻿--Import init data
insert into VendorType (name) values('BeerFactory');
insert into Town (name) values('Plovidv'),('Sofia'),('Varna'),('Burgas'); 
insert into Measure (measure_name) values ('kolichestvo'),('Broi');
insert into Currency (name) values ('Euro'),('Leva'),('Dollar');