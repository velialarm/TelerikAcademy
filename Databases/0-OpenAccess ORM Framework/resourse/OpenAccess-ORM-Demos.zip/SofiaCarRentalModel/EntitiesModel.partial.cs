﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Telerik.OpenAccess;

namespace OpenAccessModel9
{
    public partial class EntitiesModel
    {
        static EntitiesModel()
        {
            //BackendConfiguration.MergeBackendConfigurationFromConfigFile(backend,
            //    ConfigurationMergeMode.ConfigFileDefinitionWins, "oaConfig");
        }
    }
}