﻿create procedure GetPersonBooks
(
	@PersonId int
)
as
select p.FirstName, p.LastName,
	b.Title, bt.ReturnDate
from [$(School)].PersonInfo.Person p
join BookTaking bt on p.PersonId = bt.PersonId
join Book b on bt.BookId = b.BookId
where p.PersonId = @PersonId