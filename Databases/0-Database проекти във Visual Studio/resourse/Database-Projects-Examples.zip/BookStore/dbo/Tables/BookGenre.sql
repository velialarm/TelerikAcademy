﻿CREATE TABLE [dbo].[BookGenre] (
    [BookGenreId] INT IDENTITY (1, 1) NOT NULL,
    [BookId]      INT NOT NULL,
    [GenreId]     INT NOT NULL,
    CONSTRAINT [FK_BookGenre_Book] FOREIGN KEY ([BookId]) REFERENCES [dbo].[Book] ([BookId]),
    CONSTRAINT [FK_BookGenre_GenreId] FOREIGN KEY ([GenreId]) REFERENCES [dbo].[Genre] ([GenreId])
);

