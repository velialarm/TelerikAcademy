﻿CREATE TABLE [dbo].[Book] (
    [BookId]         INT            IDENTITY (1, 1) NOT NULL,
    [Title]          NVARCHAR (100) NOT NULL,
    [PublishingDate] DATETIME       NULL,
    CONSTRAINT [PK_Book] PRIMARY KEY CLUSTERED ([BookId] ASC)
);

