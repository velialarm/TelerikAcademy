﻿CREATE TABLE [dbo].[BookTaking] (
    [BookTakingId] INT      IDENTITY (1, 1) NOT NULL,
    [PersonId]     INT      NOT NULL,
    [BookId]       INT      NOT NULL,
    [ReturnDate]   DATETIME NULL,
    CONSTRAINT [PK_BookTakings] PRIMARY KEY CLUSTERED ([BookTakingId] ASC),
    CONSTRAINT [FK_BookTakings_Book] FOREIGN KEY ([BookId]) REFERENCES [dbo].[Book] ([BookId])
);

