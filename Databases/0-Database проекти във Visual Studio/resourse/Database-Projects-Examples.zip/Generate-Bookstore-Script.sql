USE [master];
GO

IF EXISTS (SELECT * FROM sys.databases WHERE name = 'Bookstore')
	DROP DATABASE Bookstore;
GO

create database Bookstore;

create table Book
(
	BookId int identity(1,1) not null,
	Title nvarchar(100) not null,
	PublishingDate datetime null,
	constraint [PK_Book] primary key clustered ([BookId] ASC)
);

create table Genre
(
	GenreId int identity(1,1) not null,
	Name nvarchar(100) not null,
	constraint [PK_Genre] primary key clustered (GenreId ASC)
);

create table BookGenre
(
	BookGenreId int identity(1,1) not null,
	BookId int not null,
	GenreId int not null,
	CONSTRAINT [FK_BookGenre_Book] FOREIGN KEY([BookId])
		REFERENCES [dbo].[Book] ([BookID]),		
	CONSTRAINT [FK_BookGenre_GenreId] FOREIGN KEY([GenreId])
		REFERENCES [dbo].[Genre] ([GenreId])
);

create table BookTaking
(
	BookTakingId int identity(1,1) not null,
	PersonId int not null,
	BookId int not null,
	ReturnDate datetime null,
	constraint [PK_BookTakings] primary key clustered ([BookTakingId] ASC),
	CONSTRAINT [FK_BookTakings_Book] FOREIGN KEY([BookId])
		REFERENCES [dbo].[Book] ([BookID])	
);

insert into Book
values
('Lord of the rings', '2000-04-01'),
('Hitchhiker''s guide to the galaxy','2001-05-17'),
('Alice in wonderland', '2002-09-18'),
('Harry potter and the deathly hallows', '2011-10-09');

insert into Genre
values
('Fantasy'),
('Adventure'),
('Sci-fi'),
('Comedy');

insert into BookGenre
values
(1,1),(1,2),
(2,3),(2,4),
(3,2),
(4,1),(4,2)

insert into BookTaking
values
(26,1,'2012-08-12'),
(19,2,NULL),
(5,1,NULL),
(16,3,'2012-12-05')
