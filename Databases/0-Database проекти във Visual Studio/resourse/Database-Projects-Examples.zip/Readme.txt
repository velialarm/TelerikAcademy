First install SQL Server Data Tools: http://msdn.microsoft.com/en-US/data/tools.aspx

