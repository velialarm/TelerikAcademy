﻿CREATE SCHEMA [CourseInfo]
    AUTHORIZATION [dbo];

