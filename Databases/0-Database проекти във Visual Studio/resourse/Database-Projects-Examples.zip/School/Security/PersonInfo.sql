﻿CREATE SCHEMA [PersonInfo]
    AUTHORIZATION [dbo];

