﻿CREATE TABLE [PersonInfo].[CourseInstructor] (
    [CourseID] INT NOT NULL,
    [PersonID] INT NOT NULL,
    CONSTRAINT [PK_CourseInstructor] PRIMARY KEY CLUSTERED ([CourseID] ASC, [PersonID] ASC),
    CONSTRAINT [FK_CourseInstructor_Course] FOREIGN KEY ([CourseID]) REFERENCES [CourseInfo].[Course] ([CourseID]),
    CONSTRAINT [FK_CourseInstructor_Person] FOREIGN KEY ([PersonID]) REFERENCES [PersonInfo].[Person] ([PersonID])
);

