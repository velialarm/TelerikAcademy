﻿
CREATE PROCEDURE [dbo].[DeletePerson]
		@PersonID int
		AS
		DELETE FROM [PersonInfo].Person WHERE PersonID = @PersonID;
