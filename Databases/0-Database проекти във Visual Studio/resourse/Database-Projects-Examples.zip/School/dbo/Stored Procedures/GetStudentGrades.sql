﻿
CREATE PROCEDURE [dbo].[GetStudentGrades]
            @StudentID int
            AS
            SELECT EnrollmentID, Grade, CourseID,
				p.FirstName, p.LastName 
            FROM [PersonInfo].StudentGrade sg
            JOIN [PersonInfo].Person p on sg.StudentId = p.PersonId 
            WHERE StudentID = @StudentID
