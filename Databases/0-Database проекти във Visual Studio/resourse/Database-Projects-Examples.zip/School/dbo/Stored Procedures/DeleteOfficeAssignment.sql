﻿
CREATE PROCEDURE [dbo].[DeleteOfficeAssignment]
		@InstructorID int
		AS
		DELETE FROM [PersonInfo].OfficeAssignment
		WHERE InstructorID=@InstructorID;
