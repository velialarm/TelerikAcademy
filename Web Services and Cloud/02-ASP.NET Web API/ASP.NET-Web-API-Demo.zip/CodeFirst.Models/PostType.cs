﻿namespace CodeFirst.Models
{
    public enum PostType
    {
        Normal = 0,
        Important = 1,
        Hidden = 2,
    }
}
