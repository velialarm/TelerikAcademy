﻿namespace BunniesCraft.Models
{
    public enum ColorType
    {
        Red,
        Blue,
        White,
        Black
    }
}
