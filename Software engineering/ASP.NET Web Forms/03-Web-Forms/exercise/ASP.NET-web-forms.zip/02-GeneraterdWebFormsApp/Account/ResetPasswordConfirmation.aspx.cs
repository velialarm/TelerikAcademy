﻿using System.Web.UI;

namespace _02_GeneraterdWebFormsApp.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}