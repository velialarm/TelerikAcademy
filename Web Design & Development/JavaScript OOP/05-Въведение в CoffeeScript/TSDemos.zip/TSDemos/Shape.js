﻿var Shape = (function () {
    function Shape(pX, pY) {
        this.pointX = pX;
        this.pointY = pY;
    }
    Shape.prototype.getArea = function () {
        return 0;
    };
    return Shape;
})();
//# sourceMappingURL=Shape.js.map
