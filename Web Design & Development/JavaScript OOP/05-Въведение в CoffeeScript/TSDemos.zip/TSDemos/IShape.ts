﻿interface IShape {
    pointX: number;
    pointY: number;
    getArea():number;
}