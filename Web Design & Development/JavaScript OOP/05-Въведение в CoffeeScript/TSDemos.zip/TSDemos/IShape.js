﻿//# sourceMappingURL=IShape.js.map
