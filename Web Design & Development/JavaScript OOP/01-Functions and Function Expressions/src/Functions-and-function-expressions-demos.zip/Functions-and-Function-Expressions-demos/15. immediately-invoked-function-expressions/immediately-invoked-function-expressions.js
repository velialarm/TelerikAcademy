(function () {
	console.log('Invoked')
}());