exports.index = function (req, res) {
  res.send('Index Page');
};

