exports.index = function (req, res) {
    res.send('Customer Index');
};

exports.list = function (req, res) {
    res.send('Customer List');
};
