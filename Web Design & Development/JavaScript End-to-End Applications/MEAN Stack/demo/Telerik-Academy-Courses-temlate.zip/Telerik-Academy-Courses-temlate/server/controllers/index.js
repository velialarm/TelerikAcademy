var usersController = require('../controllers/usersController');
var coursesController = require('../controllers/coursesController');

module.exports = {
    users: usersController,
    courses: coursesController
}