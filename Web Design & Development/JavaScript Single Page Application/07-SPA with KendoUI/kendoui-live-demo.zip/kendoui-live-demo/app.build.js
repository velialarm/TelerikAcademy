({
  baseUrl: './app/scripts',
  paths: {
    text: '../bower_components/requirejs-text/text'
  },
  name: 'main',
  out: 'app/scripts/main-built.js'
})