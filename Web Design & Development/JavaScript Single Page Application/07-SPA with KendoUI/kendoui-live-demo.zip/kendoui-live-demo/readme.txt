run on the CMD/Terminal
$ bower install
$ npm install