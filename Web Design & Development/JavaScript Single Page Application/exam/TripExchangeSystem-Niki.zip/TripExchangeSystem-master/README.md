Trip Exchange System
====================

Trip Exchange System is a system for shared trips.

The server is based on ASP.NET Web API

The client is based on AngularJS

The service is deployed on: http://spa2014.bgcoder.com

(This system has been used as services for the Single Page Applications Exam in Telerik Academy 2014)
