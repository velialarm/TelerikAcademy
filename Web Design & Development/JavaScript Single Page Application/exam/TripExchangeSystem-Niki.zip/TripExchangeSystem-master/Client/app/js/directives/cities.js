'use strict';

tripExchange.directive('cities', [function() {
    return {
        restrict: 'A',
        templateUrl: 'views/directives/cities.html'
    }
}]);